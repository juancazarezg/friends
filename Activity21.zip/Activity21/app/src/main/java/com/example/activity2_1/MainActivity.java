package com.example.activity2_1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import static android.provider.AlarmClock.EXTRA_MESSAGE;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, Handler.Callback{

    private RecyclerView recycler;
    private ArrayList<String[]> friends;
    private Handler handler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recycler = findViewById(R.id.recyclerView2);

        friends = new ArrayList<>();

        handler = new Handler(Looper.getMainLooper(), this);


    }

    @Override
    public void onClick(View view) {
        Intent intent = new Intent(this, InfoFriend.class);
        int pos = recycler.getChildLayoutPosition(view);
        intent.putExtra("name", friends.get(pos)[0]);
        intent.putExtra("hobby", friends.get(pos)[1]);
        intent.putExtra("age", friends.get(pos)[2]);
        intent.putExtra("phone", friends.get(pos)[3]);
        intent.putExtra("address", friends.get(pos)[4]);
        startActivity(intent);

    }

    public void doRequest(View v) {
        Request request = new Request("https://raw.githubusercontent.com/juancazarezg/friends/main/friends.json", handler);
        request.start();
    }

    @Override
    public boolean handleMessage(@NonNull Message message) {
        JSONArray data = (JSONArray) message.obj;

        try{
            for(int i = 0; i < data.length(); i++){
                JSONObject actual = data.getJSONObject(i);
                String[] datos = {
                        actual.getString("name"),
                        actual.getString("hobby"),
                        actual.getString("age"),
                        actual.getString("phone"),
                        actual.getString("adress")};
                friends.add(datos);
                Log.wtf("FRIENDS", actual.getString("name"));
            }

            FriendsAdapter adapter = new FriendsAdapter(friends, this);
            LinearLayoutManager llm = new LinearLayoutManager(this);
            llm.setOrientation(LinearLayoutManager.VERTICAL);

            recycler.setLayoutManager(llm);
            recycler.setAdapter(adapter);

        }catch (JSONException e) {
            e.printStackTrace();
        }


        return false;
    }
}