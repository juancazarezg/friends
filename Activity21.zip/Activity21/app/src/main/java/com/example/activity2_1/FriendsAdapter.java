package com.example.activity2_1;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class FriendsAdapter extends RecyclerView.Adapter<FriendsAdapter.FriendsViewHolder> {

    public static class FriendsViewHolder extends RecyclerView.ViewHolder{
        //view holder- class in charge of dealing with a row

        public TextView name, hobby;

        public FriendsViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.textView5);
            hobby = itemView.findViewById(R.id.textView4);
        }

    }

    private ArrayList<String[]> friends;
    private View.OnClickListener listener;

    public FriendsAdapter(ArrayList<String[]> doggies, View.OnClickListener listener){
        this.friends = doggies;
        this.listener = listener;
    }

    @NonNull
    @Override
    public FriendsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        //parse from xml to java object
        View v = (View) LayoutInflater.from(parent.getContext()).inflate(R.layout.info, parent, false);

        v.setOnClickListener(listener);

        FriendsViewHolder dvh = new FriendsViewHolder(v);
        return dvh;
    }

    @Override
    public void onBindViewHolder(@NonNull FriendsViewHolder holder, int position) {
        holder.name.setText(friends.get(position)[0]);
        holder.hobby.setText(friends.get(position)[1]);
    }

    @Override
    public int getItemCount() {
        return friends.size();
    }


}
