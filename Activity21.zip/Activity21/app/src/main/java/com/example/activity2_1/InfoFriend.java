package com.example.activity2_1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class InfoFriend extends AppCompatActivity {

    private TextView name, hobby, age, phone, address;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info_friend);

        name = findViewById(R.id.textView10);
        hobby = findViewById(R.id.textView11);
        age = findViewById(R.id.textView12);
        phone = findViewById(R.id.textView13);
        address = findViewById(R.id.textView14);

        Intent intent = getIntent();

        name.setText(intent.getStringExtra("name"));
        hobby.setText(intent.getStringExtra("hobby"));
        age.setText(intent.getStringExtra("age"));
        phone.setText(intent.getStringExtra("phone"));
        address.setText(intent.getStringExtra("address"));


    }
}